# Building_3 > 2024-01-10 7:46pm
https://universe.roboflow.com/lviv-national-university-of-ivan-franko/building_3

Provided by a Roboflow user
License: CC BY 4.0

